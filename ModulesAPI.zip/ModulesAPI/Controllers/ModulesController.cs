﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModulesAPI.Data;
using ModulesAPI.Models;

namespace ModulesAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModulesController : ControllerBase
    {
        private readonly ModulesAPIDbContext dbContext;

        public ModulesController(ModulesAPIDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        [HttpGet]

        public async Task<IActionResult> GetPaymentDetailsAsync()
        {
            return Ok(await dbContext.Modules.ToListAsync());
        }


        [HttpGet]
        [Route("{id:guid}")]
        public async Task<IActionResult> GetContact([FromRoute] Guid id)
        {
            var module = await dbContext.Modules.FindAsync(id);
            if (module == null)
            {
                return NotFound();
            }

            return Ok(module);

        }
        //Http for put 
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateModules([FromRoute] Guid id, UpdateModulesRequest updateModulesRequest)
        {
            var module = await dbContext.Modules.FindAsync(id);
            if (module != null)
            {

                module.Code = updateModulesRequest.Code;
                module.Name = updateModulesRequest.Name;
                module.Credits = updateModulesRequest.Credits;
                module.ClassHour = updateModulesRequest.ClassHour;

                await dbContext.SaveChangesAsync();
                return Ok(module);

            }
            return NotFound();

        }

        //Http for post
        [HttpPost]
        public async Task<IActionResult> AddModules(AddModulesRequest addModulesRequest)
        {
            var module = new Modules()
            {
                ID = Guid.NewGuid(),
            Code = addModulesRequest.Code,
            Name = addModulesRequest.Name,
            Credits = addModulesRequest.Credits,
            ClassHour = addModulesRequest.ClassHour

        };
            await dbContext.Modules.AddAsync(module);
            await dbContext.SaveChangesAsync();
            return Ok(module);
        }

        //Http for delete
        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteModules([FromRoute] Guid id)
        {
            var module = await dbContext.Modules.FindAsync(id);
            if (module != null)
            {
                dbContext.Remove(module);
                await dbContext.SaveChangesAsync();
                return Ok(module);
            }

            return NotFound();

        }
    }
}
