﻿using Microsoft.EntityFrameworkCore;
using ModulesAPI.Models;

namespace ModulesAPI.Data
{
    public class ModulesAPIDbContext : DbContext
    {
      
            public ModulesAPIDbContext(DbContextOptions options) : base(options)
            {
            }

            public DbSet<Modules> Modules { get; set; }
        

    }
}
