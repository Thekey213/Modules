﻿namespace ModulesAPI.Models
{
    public class Modules
    {

        public Guid ID { get; set; }
        public string Code { get; set; }

        public string Name { get; set; }

        public int Credits { get; set; }
        public int ClassHour { get; set; }

        public Modules()
        {



        }


    }
}
