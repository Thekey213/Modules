﻿namespace ModulesAPI.Models
{
    public class AddModulesRequest
    {
        public string Code { get; set; }

        public string Name { get; set; }

        public int Credits { get; set; }
        public int ClassHour { get; set; }
    }
}
